# Lambda-packaged research engine
